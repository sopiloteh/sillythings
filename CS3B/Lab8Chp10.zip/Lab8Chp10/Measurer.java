/******************************************************************************
CS003B Java
Yonas Adamu & Erick Bravo
07/16/20
P10.7 Lambada
*******************************************************************************/

public interface Measurer 
{   
    // sizes up the bank account using anObject
    double measure(Object anObject);    
}
