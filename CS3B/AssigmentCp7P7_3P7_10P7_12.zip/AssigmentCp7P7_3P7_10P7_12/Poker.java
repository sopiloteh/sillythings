/******************************************************************************
CS003B Java
Erick Bravo
07/03/20
P7.12 Video Poker
*******************************************************************************/

public class Poker 
{
    public static void main(String[] args)
    {
        // starting a new session of video poker
        Deck myDeck = new Deck();
        myDeck.playPoker();
    }

}
