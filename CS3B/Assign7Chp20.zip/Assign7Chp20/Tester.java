/******************************************************************************
CS003B Java
Erick Bravo
07/11/20
P20.01 rectangles
*******************************************************************************/

import javax.swing.JFrame;

public class Tester 
{
    public static void main(String[] args)
    {
        // main title bar, sets size and when to close
        JFrame frame = new Frame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Rectangles");
        frame.setSize(300,300);
        frame.setVisible(true);
    }
    
}
