/******************************************************************************
CS003B Java
Erick Bravo
07/11/20
P20.04 Bank Bar graph
*******************************************************************************/


import javax.swing.JFrame;

public class BankBarChartTester
{
   public static void main (String[] args)
   {
       JFrame frame = new BankBarChartFrame();
       frame.setTitle("Bank Bar Chart Frame");
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.show();
   }  
}
