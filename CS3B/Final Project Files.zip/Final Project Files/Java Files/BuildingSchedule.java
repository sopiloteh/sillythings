/******************************************************************************
CS003B Java
Erick Bravo
07/20/20
Final Project Planner
*******************************************************************************/

/**
 * Turns out Scheduable does most of this work, it would condense
 * classes but make it longer
 * @author erickbravo
 */
public class BuildingSchedule 
{
    
    /**
     *
     */
    public BuildingSchedule()
    {
        
    }
    
    /**
     * prints out the schedule to a file
     */
    public void viewSchedule()
    {
        
    }
    
}
