/******************************************************************************
CS003B Java
Erick Bravo
07/20/20
Final Project Planner
*******************************************************************************/


/**
 * This portion of the code will check to see if the user 
 * has set a time and length to that time
 * @author erickbravo
 */


public class Time 
{
    int startTime;
    int length;
    
    /**
     * exports out from CollegeBuilding to be able to be scheduled
     * in scheduable 
     */
    public Time ()
    {
        while (startTime > 6 || startTime < 22)
        {
            //time = Time;
        }
    }
    
}
