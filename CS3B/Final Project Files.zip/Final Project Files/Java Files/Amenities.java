/******************************************************************************
CS003B Java
Erick Bravo
07/20/20
Final Project Planner
*******************************************************************************/

/**
 * This part of the code evaluates if any superflous items are needed
 * It is a subclass
 * @author erickbravo
 */
public class Amenities extends ClassRoom
{

    /**
     *
     * @param Projector a radio button event for wanting a projector
     * @param Printer a radio button event for wanting a printer
     */
    public Amenities(int Projector, int Printer)
    {
        
    }
    
}
